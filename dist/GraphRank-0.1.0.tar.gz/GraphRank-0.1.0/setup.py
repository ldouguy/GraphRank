from distutils.core import setup

setup(name='GraphRank',
	version='0.1.0',
	description='GraphRank Core Classes and Utils',
	author='Sean Douglas',
	author_email='douglas.seanp@gmail.com',
	url='https://github.com/ldouguy/GraphRank',
	packages=['graphrank'],
)