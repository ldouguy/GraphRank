import GraphUtils as gu

class GRT:
	def __init__(self, multiGraph):

	def prerank(self):

	def rank(self, player):

	def reduce(self):